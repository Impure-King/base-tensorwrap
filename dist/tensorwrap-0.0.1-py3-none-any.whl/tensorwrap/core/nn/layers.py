import jax.numpy as jnp
from jax import jit, grad, vmap, random