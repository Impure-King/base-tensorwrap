import tensorwrap as tw
import pytest

def test_version():
    assert tw.__version__ == "0.0.1.7"