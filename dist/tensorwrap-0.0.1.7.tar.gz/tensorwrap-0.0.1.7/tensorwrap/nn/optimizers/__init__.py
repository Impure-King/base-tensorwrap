from tensorwrap.nn.optimizers.base import (Optimizer,
                   gradient_descent)