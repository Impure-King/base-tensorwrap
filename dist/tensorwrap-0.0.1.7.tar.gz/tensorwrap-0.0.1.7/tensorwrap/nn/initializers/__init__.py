from .base import (GlorotUniform,
                   GlorotNormal,
                   Initializer,
                   Zeros)