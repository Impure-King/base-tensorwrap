"""This module manages the current version of TensorWrap that is being developed."""

__version__ = "0.0.1.7"
